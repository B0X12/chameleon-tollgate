﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthClient.tollgate.util.tollgateLog.dto.code
{
    interface LogCode
    {
        string getMessage();
        int getCode();
    }
}
